package pack1;

import java.util.*;
public class Circle {

double radius=1.0;
String colour="red";

public Circle(){
	
}

public Circle(double r){
   
}

public double getRadius(double d){
	double r=(d/2);
	return r;
}

public double getArea(double d){
	double a;
	a=(3.14*(d/2)*(d/2));
	return a;
}

	public static void main(String[] args) {
		
		double dia;
		Scanner sc=new Scanner(System.in);
		Circle c1=new Circle();
		System.out.println("Enter the diameter of the circle: ");
		dia=sc.nextDouble();
		System.out.println("\n\nThe radius of the circle is: "+c1.getRadius(dia));
		System.out.println("The area of the circle is: "+c1.getArea(dia));
		sc.close();
	}

}
