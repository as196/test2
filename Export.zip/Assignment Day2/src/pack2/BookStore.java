package pack2;

import java.io.*;
import java.io.InputStreamReader;
import java.util.*;

import pack2.Book;

public class BookStore
{
	Book[] books = new Book[10];
	
	void sell(String bookTitle, int noOfCopies)
	{
		Scanner scan=new Scanner(System.in);
		boolean flag, found=false;
		
		for(int i=0; i<books.length; i++)
		{
			if(books[i] instanceof Book)
			{
				if(bookTitle.equals(books[i].bookTitle))
				{
					flag = true;
					while(flag)    //checks for ture
					{
						if(books[i].numOfCopies>=noOfCopies)
						{
							found=true;
							books[i].numOfCopies -= noOfCopies;
							flag=false;
							
						}
						else
						{
							System.out.print(books[i].bookTitle+" has "+books[i].numOfCopies+" copies.\nPlease enter a number less than books available: ");
							noOfCopies=scan.nextInt();
						}
					}
				}
			}
		}
		if(!found)
		{
			System.out.println("Book not available with this name.");
		}
		else
		{
			System.out.println("Book sold!");
		}
		scan.close();
	}
	
	
	void order(String isbn, int noOfCopies)
	{
		boolean found=false;
		int pos=0;
		
		for(int i=0;i<books.length;++i)
		{
			if(books[i] instanceof Book)
			{
				if(isbn.equals(books[i].ISBN))
				{
					found= true;
					books[i].numOfCopies+= noOfCopies;
				}
			}
		}
		
		if(!found)
		{
			System.out.println("Book not found in record.");
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			String bookTitle = "";
			String author= "";
			try
			{
				System.out.print("New book name: ");
				bookTitle=br.readLine();
				System.out.print("New book auther's name: ");
				author=br.readLine();
			}catch (IOException e) {}
			
			for(Book book:books)
			{
				if(book instanceof Book)
				{
					++pos;
				}
			}
			books[pos]=new Book(bookTitle, author, isbn, noOfCopies);
			
		}
		
		System.out.println("Book ordering successful.");
		
	}
	

	
	void display()
	{
		boolean flag=false;
		for(Book book:books)
		{
			if(book instanceof Book)
			{
				book.display();
				flag = true;
			}
		}
		if(!flag)
		{
			System.out.println("No book with that name!");
		}
	}
	
	
}
