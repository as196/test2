package pack2;

import pack2.BookStore;
import java.util.*;
import java.io.*;
import java.io.InputStreamReader;

public class BookStoreApp {

	public static void main(String[] args) {
		boolean menuShow = true;
		Scanner sc = new Scanner(System.in);
		BookStore bookStore = new BookStore();
		String isbn;
		String bookTitle="";
		int noOfCopies=0;
		boolean flag;
		boolean againPerform;
		String againInputOption;
		
		bookStore.books[0] = new Book("Physics", "H.C.Verma", "1234567890", 6);

		do{
			
		System.out.println("Enter �1�, to display the Books: Title � Author � ISBN - Quantity.");
		System.out.println("Enter �2�, to order new books.");
		System.out.println("Enter �3�, to sell books.");
		System.out.println("Enter �0�, to exit the system.");
		System.out.print("Please enter your input option: ");
		
		String input;
		
		input = sc.next();
		
		switch(input)
		{
			case "1":System.out.println("Available Book Details:");
					bookStore.display();
					System.out.println("[][][][][][][][][][][][][][][][][][][]\n");
					break;

			case "2":againPerform = true;
					System.out.println("Order Book:");
					do
					{	
						System.out.print("Please enter ISBN no. of book: ");
						isbn = sc.next();
						flag = true;
						do
						{
							System.out.print("Please enter no of copies to order: ");
							if(sc.hasNextInt())
							{
								noOfCopies = sc.nextInt();
								if(noOfCopies <0)
								{
									System.out.println("Invalid number of books. Books no. should be greater than 0.");
								}
								else
								{
									flag=false;
								}
							}
						}while(flag);
						bookStore.order(isbn, noOfCopies);
						System.out.print("Do you want to order another book? [y/n]: ");
						againInputOption = sc.next();
						
						if(againInputOption.equals("y") || againInputOption.equals("Y"))
						{
							againPerform = true;
						}
						else
						{
							againPerform = false;
						}
						System.out.println();
					}while(againPerform);
					System.out.println("[][][][][][][][][][][][][][][][][][][]\n");
					break;

			case "3":againPerform = true;
					System.out.println("Sell Book:");
					do
					{
						System.out.print("Please enter title of book: ");
						BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
						try {
							bookTitle = br.readLine();
						} catch (IOException e) {}
						flag = true;
						do
						{
							System.out.print("Please enter no of copies to sell: ");
							if(sc.hasNextInt())
							{
								noOfCopies = sc.nextInt();
								if(noOfCopies <0)
									{
									System.out.println("Invalid no. of books. Books no. should be greater than 0.");
									}
								else
								{
									flag=false;
								}
							}
						}while(flag);
						bookStore.sell(bookTitle, noOfCopies);
						System.out.print("Do you want to sell another book? [y/n]: ");
						againInputOption = sc.next();
						if(againInputOption.equals("y") || againInputOption.equals("Y"))
						{
							againPerform = true;
						}
						else
						{
							againPerform = false;
						}
						System.out.println();
					}while(againPerform);
					System.out.println("[][][][][][][][][][][][][][][][][][][]\n");
					break;
		
			case "0":System.out.println("\nThank you for using Book Store.\nI will be waiting for you to return.....");
					menuShow = false;
					System.exit(0);
					break;
			
			default:System.out.println("**** Error: Invalid Input Option *****\n");
					break;
		}
	
		}while(menuShow);
	sc.close();


	}

}
