package pack1;

public class Fibonacci {

	public static void main(String[] args) {

		int a = 1;
		int b = 1;
		int temp;
		float avg, sum = 2;
		System.out.println("The first 20 Fibonacci numbers are:");
		System.out.print(a + " " + b + " ");
		for (int i = 2; i < 20; i++) {
			temp = a + b;
			a = b;
			b = temp;
			System.out.print(temp + " ");
			sum += temp;
		}

		avg = sum / 20;
		System.out.println("\nThe average is " + avg);
	}

}
