package pack5;

public class NumPyramid {

	public static void main(String[] args) {
		
		for(int i=0;i<9;i++){
			for(int j=0;j<i;j++){
				System.out.print(j+1);
			}
			System.out.println(" ");
			}
		}

}
