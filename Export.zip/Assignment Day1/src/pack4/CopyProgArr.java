package pack4;

public class CopyProgArr {

	public static int[] copyOf(int[] array) {

		int Arr[] = array;
		return Arr;

	}

	public static void main(String[] args) {

		int arr[] = { 1, 2, 3, 4, 5, 6 };
		int arr2[];

		arr2 = copyOf(arr);
		System.out.print("Array after being copied: ");
		for (int i = 0; i < arr2.length; i++) {
			System.out.print(" " + arr[i]);
		}

	}

}
