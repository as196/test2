package pack2;

public class TimeTable {

	public static void main(String[] args) {

		int a;

		for (int i = 0; i < 10; i++) {
			if (i == 0) {
				System.out.print("*| ");
			} else

				System.out.print(i + " ");

		}
		System.out.println();
		for (int i = 0; i < 20; i++) {
			System.out.print("-");
		}
		System.out.println();
		for (int i = 1; i < 10; i++) {

			System.out.print(i + "| ");

			for (int j = 1; j < 10; j++) {

				a = i * j;
				System.out.print(a + " ");
			}
			System.out.println();

		}

	}

}
