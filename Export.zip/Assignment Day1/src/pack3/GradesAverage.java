package pack3;

import java.util.*;

public class GradesAverage {


	public static void main(String[] args) {

		int n=0;
		int m=0;
		float sum=0;
		float avg=0;

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of students: ");
		n = sc.nextInt();
		float students[] = new float[n];

		for (int i = 0; i < n; i++) {

			System.out.println("Enter the grades of student " + (i + 1) + ":");
			m = sc.nextInt();
			if (m < 0 || m > 100)
			{
				System.out.println("Invalid grades.");
				i--;
			} 
			else 
			{
				students [i]=m ;
			}
		}
		
		for(int i=0;i<n;i++){
			sum+=students[i];
		}
		
		avg=sum/n;
		System.out.println("The average is: "+avg);
		sc.close();

	}

}
