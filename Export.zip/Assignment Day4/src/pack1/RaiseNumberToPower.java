package pack1;

public class RaiseNumberToPower {
	String calculate(Object a1, Object a2) {
		if (a1 instanceof Double) {
			if (a2 instanceof Double) {
				return "" + Math.pow((Double) a1, (Double) a2);
			} else if (a2 instanceof Float) {
				return "" + Math.pow((Double) a1, (Float) a2);
			} else if (a2 instanceof Long) {
				return "" + Math.pow((Double) a1, (Long) a2);
			} else if (a2 instanceof Integer) {
				return "" + Math.pow((Double) a1, (Integer) a2);
			}
		} else if (a1 instanceof Long) {
			if (a2 instanceof Double) {
				return "" + Math.pow((Long) a1, (Double) a2);
			} else if (a2 instanceof Float) {
				return "" + Math.pow((Long) a1, (Float) a2);
			} else if (a2 instanceof Long) {
				return "" + Math.pow((Long) a1, (Long) a2);
			} else if (a2 instanceof Integer) {
				return "" + Math.pow((Long) a1, (Integer) a2);
			}
		} else if (a1 instanceof Float) {
			if (a2 instanceof Double) {
				return "" + Math.pow((Float) a1, (Double) a2);
			} else if (a2 instanceof Float) {
				return "" + Math.pow((Float) a1, (Float) a2);
			} else if (a2 instanceof Long) {
				return "" + Math.pow((Float) a1, (Long) a2);
			} else if (a2 instanceof Integer) {
				return "" + Math.pow((Float) a1, (Integer) a2);
			}
		} else if (a1 instanceof Integer) {
			if (a2 instanceof Double) {
				return "" + Math.pow((Integer) a1, (Double) a2);
			} else if (a2 instanceof Float) {
				return "" + Math.pow((Integer) a1, (Float) a2);
			} else if (a2 instanceof Long) {
				return "" + Math.pow((Integer) a1, (Long) a2);
			} else if (a2 instanceof Integer) {
				return "" + Math.pow((Integer) a1, (Integer) a2);
			}
		}
		
		return "Wrong";
	}

	double calculate(double number, int pow) {
		double temp = 1;
		for (int i = 0; i < pow; i++) {
			temp *= number;
		}
		return temp;
	}

	float calculate(float number, int pow) {
		float temp = 1;
		for (int i = 0; i < pow; i++) {
			temp *= number;
		}
		return temp;
	}

	int calculate(int number, int pow) {
		int temp = 1;
		for (int i = 0; i < pow; i++) {
			temp *= number;
		}
		return temp;
	}

	long calculate(long number, int pow) {
		long temp = 1;
		for (int i = 0; i < pow; i++) {
			temp *= number;
		}
		return temp;
	}

	public static void main(String[] args) {
		RaiseNumberToPower r = new RaiseNumberToPower();

		System.out.println("55L ^ 5 = " + r.calculate(55L, 5)); // long value
		System.out.println("-14 ^ 8 = " + r.calculate(-14, 8)); // integer value
		System.out.println("45.6923 ^ 4 = " + r.calculate(45.6923, 4)); // double
																		// value
		System.out.println("1155.6f ^ 2 = " + r.calculate(1155.6f, 2)); // float
																		// value
	}

}
