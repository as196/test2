package pack1;

import java.util.Scanner;

class math {

	public double pow(double a, double b) {

		double c = 1;

		for (int i = 0; i < b; i++) {
			c = c * a;
		}

		return c;
	}
}

public class Power extends math {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		double a, b;
		System.out.println("Enter a numer: ");
		a = sc.nextDouble();
		System.out.println("To what power you want to multiply: ");
		b = sc.nextDouble();
		math cal = new Power(); //Poly
		System.out.println("The answer is: ");
		double c = cal.pow(a, b);
		System.out.println(c);
		sc.close();
	}

}
