package pack3;

import java.util.Scanner;


 class Car{
	
	 String ModelOfCar(String... value){
		 
		 String Model="";
		 for(String n : value){
			 if(n=="SUV"){
				Model="TATA SAFARI";
			 }
			 else if(n=="SEDAN"){
				 Model="TATA INDIGO";
			 }
			 else if(n=="ECONOMY"){
				 Model="TATA INDICA";
			 }
			 else if(n=="MINI"){
				 Model="TATA NANO";
			 }
		 }
		return Model; 
	 }
}



 public class CarType extends Car{

	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		do
		{
		int a;
		Car c1=new Car();	
		System.out.println("Which type of car do you want to buy");
		System.out.println("Press 1 for SUV.");
		System.out.println("Press 2 for SEDAN.");
		System.out.println("Press 3 for ECONOMY.");
		System.out.println("Press 4 for MINI.");
		a=sc.nextInt();
		
		
		switch(a)
		{
		case 1: String type="SUV";
		           System.out.println("Under SUV category we have "+c1.ModelOfCar(type)+" as an option.");        
		            break;
		              
		case 2: String type2="SEDAN";
		           System.out.println("Under SEDAN category we have "+c1.ModelOfCar(type2)+" as an option."); 
                    break;
                      
		case 3: String type3="ECONOMY";
		            System.out.println("Under ECONOMY category we have "+c1.ModelOfCar(type3)+" as an option."); 
                     break;
                      
		case 4: String type4="MINI";
		           System.out.println("Under MINI category we have "+c1.ModelOfCar(type4)+" as an option."); 
                    break;               
		
		default:System.out.println("**** Error: Invalid Input Option *****\n");
		             break;               
		}
		
		} while(true);
	}

}
