package pack4;

public class OverLoad {

	
	
	public static void main(String[] args) {
		
	}

}
