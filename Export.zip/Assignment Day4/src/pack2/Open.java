package pack2;

import java.util.Scanner;

public class Open {

	void Open1(String... value){
		
		for(String n : value){
			System.out.println("Opening a "+n);
		}
	}
	
	
	public static void main(String[] args) {
	
		Scanner sc=new Scanner(System.in);
		Open c1= new Open();
		System.out.println("What do you want to open: ");
		String open=sc.next();
		c1.Open1(open);
		sc.close();
	}

}
